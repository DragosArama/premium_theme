<?php

    require_once("lib/helpers.php");
    require_once("lib/enqueue-assets.php");
    require_once("lib/sidebars.php");
    require_once("lib/theme-support.php");
    require_once("lib/navigation.php");
    require_once("lib/metaboxes.php");
    require_once("lib/shortcodes.php");


    function after_pagination() {
        echo 'action hook here';
    }

    add_action('mobius_after_pagination', 'after_pagination');
    remove_action('mobius_after_pagination', 'after_pagination');
    
    function example_filter($text) {
        return $text . ' mobius';
    }
    add_filter('mobius_filter', 'example_filter');

    function filter_title($title) {
        return 'Filtered ' . $title;
    }
    add_filter('the_title', 'filter_title');
?>