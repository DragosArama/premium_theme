
            <?php get_template_part('template-parts/footer/footer', 'widgets') ?>

            <?php wp_footer(); ?>
        </div>
    </body>
</html>