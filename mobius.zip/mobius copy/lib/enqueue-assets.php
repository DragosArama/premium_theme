<?php

function mobius_assets() {
    wp_enqueue_style( 'mobius-stylesheet', get_template_directory_uri() . '/dist/assets/css/bundle.css', array(), '1.0.0', 'all' );

    wp_enqueue_script( 'mobius-script', get_template_directory_uri() . '/dist/assets/js/bundle.js', array('jquery'), '1.0.0', true);

    wp_localize_script( 'mobius-script', 'to_js', ['x' => $GLOBALS['x']] );
}

add_action('wp_enqueue_scripts', 'mobius_assets');

function mobius_admin_assets() {
    wp_enqueue_style( 'mobius-admin-stylesheet', get_template_directory_uri() . '/dist/assets/css/admin.css', array(), '1.0.0', 'all' );

    wp_enqueue_script( 'mobius-admin-script', get_template_directory_uri() . '/dist/assets/js/admin.js', array(), true);
}

add_action('admin_enqueue_scripts', 'mobius_admin_assets');