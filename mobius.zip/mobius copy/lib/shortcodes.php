<?php

function mobius_button($atts = [], $content = null, $tag = 'mobius_button') {
    ob_start();
    
    extract(shortcode_atts([
        'color' => 'red',
        'content'  => 'Button'
    ], $atts, $tag));

    echo '<button style="background-color:' . esc_attr($color) . '">' . do_shortcode($content) . '</button>'; //do_shortcode is to allow nested shortcodes

    return ob_get_clean();
}

add_shortcode('mobius_button', 'mobius_button');

function mobius_button_filter() {
    return [
        'color' => 'blue',
        'content' => 'Button filter',
    ];
};
add_filter('shortcode_atts_mobius_button', 'mobius_button_filter');