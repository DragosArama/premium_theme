<?php 

    function mobius_sidebar_widgets() {
        register_sidebar( array(
            'id' => 'primary_sidebar',
            'name' => esc_html__('Primary Sidebar', 'mobius'),
            'description' => esc_html__( 'This sidebar appears in the blog posts page', 'mobius' ),
            'before_widget' => '<section id="%1$s" class=c-sidebar-widget u-margin-bottom-20 %2$s">',
            'after_widget' => '</section>',
            'before_title' => '<h5>',
            'after_title' => '</h5>'
        ));
    

        $footer_layout = "3,3,3,3";
        $columns = explode(",", $footer_layout);
        $footer_bg = 'dark';
        $widget_theme = '';

        if($footer_bg == 'light') {
            $widget_theme = 'c-footer-widget--dark';
        } else {
            $widget_theme = 'c-footer-widget--light';
        };

        foreach($columns as $i => $colum) {
            register_sidebar( array(
                'id' => 'primary_sidebar-' . ($i + 1),
                'name' => sprintf(esc_html__('Footer Widgets Column %s', 'mobius'), $i + 1),
                'description' => esc_html__( 'Footer Widgets', 'mobius' ),
                'before_widget' => '<section id="%1$s" class=c-footer-widget ' . $widget_theme . '%2$s">',
                'after_widget' => '</section>',
                'before_title' => '<h5>',
                'after_title' => '</h5>'
            ));
        }


    }
    add_action('widgets_init', 'mobius_sidebar_widgets');