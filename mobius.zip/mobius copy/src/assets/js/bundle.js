import "./components/slider";
import "./components/navigation";

(function ($) {
  let jsToPhp = to_js["x"] + " back to you";

  $.ajax({
    url: "/mobius/wp-admin/admin-ajax.php",
    type: "POST",
    data: {
      action: "js_to_php",
      theVar: jsToPhp,
    },
    success: function (data) {
      console.log(data);
    },
    error: function (errorThrown) {
      console.log(errorThrown);
    },
  });
})(jQuery);
