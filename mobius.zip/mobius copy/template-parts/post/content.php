<?php 

    $the_query = new WP_Query(
        array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => '-1'
        )
    )

?>

<?php /* echo '<pre>'; print_r($wp_query); echo '</pre>'; */ ?> <!-- The main Query -->

<?php if( $the_query->have_posts() ) : ?>

    <?php while( $the_query->have_posts() ) : $the_query->the_post(); ?>

        <article <?php post_class('c-post u-margin-bottom-20'); ?> >
            <h2 class="c-post__title">
                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
                    <?php the_title(); ?>
                </a>
            </h2>

            <div class="c-post__meta">
                <?php echo mobius_post_meta(); ?>
            </div>

            <div class="c-post__excerpt>
                <?php the_excerpt(); ?>

                <a href="<?php esc_url(get_permalink()); ?>" title="<?php esc_attr(the_title_attribute()); ?>">
                    Read More about <span class="u-screen-reader-text"> <?php the_title() ?> </span>
                </a>
            </div>
            <div><?php echo mobius_delete_post(); ?></div>
        </article>

    <?php endwhile; ?>

    <?php the_posts_pagination(); ?>

    <?php do_action('mobius_after_pagination') ?>

    <?php comments_template(); ?>

    <?php else : ?>

        <?php get_template_part('template-parts/post/content' , 'none'); ?>

<?php endif; ?>

<?php /* wp_reset_postdata(); */ ?> <!-- Used to reset the main query in case you use $wp_query() -->

<p> <?php echo apply_filters('mobius_filter', 'This is a filter', 'mobius');  ?> </p>