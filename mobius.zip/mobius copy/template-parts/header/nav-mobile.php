<div class="c-navigation c-mobile u-padding-top-10 u-padding-bottom-10">
    <div class="o-container">
        <div class="c-header__logo">
            <a class="c-header__blogname" href="<?php echo esc_url(home_url( '/' )); ?>">
                <?php get_template_part('template-parts/header/nav', 'logo'); ?>
            </a>
            <nav role="navigation header-nav">
                <div id="menuToggle">
                    
                    <input type="checkbox" />
                    
                    <span></span>
                    <span></span>
                    <span></span>
                    
                    <?php wp_nav_menu( array(
                        'theme-location' => 'main-menu',
                        'container' => false
                        ) );
                    ?>
                </div>
            </nav>
        </div>
    </div>
</div>