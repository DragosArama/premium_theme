<aside role="complementary">
    <?php dynamic_sidebar('primary_sidebar'); ?>
</aside>