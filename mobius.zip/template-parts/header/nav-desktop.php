<div class="c-navigation c-desktop">
    <div class="o-container">
        <div class="o-row">
            <div class="o-row__column o-row__column--span-12">
                <div class="c-header u-flex u-align-middle">
                    <div class="c-header__logo">
                        <a class="c-header__blogname" href="<?php echo esc_url(home_url( '/' )); ?>">
                            <?php get_template_part('template-parts/header/nav', 'logo'); ?>
                        </a>
                    </div>
                    <nav class="header-nav" role="navigation" aria-label="<?php esc_html_e( 'Main Navigation', 'mobius' ) ?>">
                        <?php wp_nav_menu( array('theme-location' => 'main-menu' ) ); ?>
                    </nav>
                    <?php get_search_form( true ) ?>
                </div>
            </div>
        </div>
    </div>
</div>