<?php

    function mobius_post_meta() { ?>
        Posted on <a class="c-post__readmore" href="<?php esc_url(get_permalink()); ?>">
        <time datetime="<?php esc_attr(get_the_date('c')) ?>"><?php echo esc_html(get_the_date()); ?></time>
        </a>

        By <a href="<?php esc_url(get_author_posts_url( get_the_author_meta('ID') )) ?>">
            <?php esc_html(get_the_author()); ?>
        </a>

    <?php };


    function mobius_php_to_js($x) {
        global $x;
        $x = 'global to js';
    }
    mobius_php_to_js('g');

    function mobius_js_to_php() {
        if(isset($_POST)) {
            $fromJs = $_POST['theVar'];

            // global $wpdb;                 // insert in DB
            // $wpdb->show_errors();
            // $table = $wpdb->prefix.'terms';
            // $data = [
            //     'name' => $fromJs
            // ];
            // $wpdb->insert($table, $data);
            // $my_id = $wpdb->insert_id;


            // var_dump($fromJs);
        };
        die();
    }
    add_action( 'wp_ajax_js_to_php', 'mobius_js_to_php' );
    add_action( 'wp_ajax_nopriv_js_to_php', 'mobius_js_to_php' );



    function mobius_wpdb_retrieve() {

        global $wpdb;

        $wpdb->show_errors();

        $posts = $wpdb->get_results("SELECT post_title FROM $wpdb->posts WHERE post_status = 'publish' AND post_type='post' ORDER BY post_date ASC LIMIT 0,4");

        $row = $wpdb->get_row("SELECT * FROM $wpdb->posts WHERE post_status = 'publish' AND post_type='post' ORDER BY post_date ASC LIMIT 0,1");

        $cols = $wpdb->get_col("SELECT post_title FROM $wpdb->posts WHERE post_status = 'publish' AND post_type='post' ORDER BY post_date ASC LIMIT 0,10");

        $reg_date = $wpdb->get_var("SELECT user_registered FROM $wpdb->users WHERE user_login = 'arama.dragos22@gmail.com' "); // met 1
        $user = 'arama.dragos22@gmail.com';
        $reg_query = $wpdb->prepare("SELECT user_registered FROM $wpdb->users WHERE user_login = %s AND ID =%d", $user, 1 ); // met 2 sanitize
        $results = $wpdb->get_var($reg_query);


        // echo '<pre>'; var_dump($results); echo '</pre>';

    }



    function mobius_delete_post() {

        $url = add_query_arg( 
            [
                'action' => 'mobius_delete_post',
                'post'   => get_the_ID(),
                'nonce'  => wp_create_nonce( 'mobius_delete_post' . get_the_ID() ) // will create a hash that contains current user id and the current sesson tokken, time and action.
            ],
            home_url()
        );

        if(current_user_can( 'delete_post', get_the_ID() )) {
            return "<a href='" . esc_url($url) . "'>" . esc_html('Delete post') . "</a>";
        }
    }

    function mobius_handle_delete_post() {
        
        if( isset($_GET['action']) && $_GET['action'] === 'mobius_delete_post' ) {
            if( !$_GET['nonce'] || !wp_verify_nonce( $_GET['nonce'], 'mobius_delete_post' . $_GET['post'] ) ) {
                return;
            }
            $post_id = isset($_GET['post']) ? $_GET['post'] : null;
            $post = get_post((int) $post_id);
            if(empty($post)) {
                return;
            }

            if(!current_user_can( 'delete_post', $post_id )) {
                return;
            }

            wp_trash_post( $post_id );
            wp_safe_redirect( home_url() );
            die();
        }
    }
    add_action('init', 'mobius_handle_delete_post');
?>
