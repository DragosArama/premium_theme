<?php
    function mobius_add_meta_boxes() {
        add_meta_box(
            'mobius_post_meta_box',
            'Post Settings',
            'mobius_post_meta_box_html',
            'post',
            'normal',
            'default',
        );
    }
    add_action( 'add_meta_boxes', 'mobius_add_meta_boxes');

    function mobius_post_meta_box_html($post) {

        $subtitle = get_post_meta( $post->ID, '__mobius_post_subtitle', true );
        $layout = get_post_meta( $post->ID, '__mobius_post_layout', true );
        wp_nonce_field( 'mobius_update_post_metabox', 'themename_update_post_nonce' );

        ?>

            <p>
                <label for="mobius_post_subtitle_field"><?php echo esc_html('Post Subtitle') ?></label>
                <br />
                <input value="<?php echo esc_attr($subtitle); ?>" class="widefat" type="text" name="mobius_post_subtitle_field" id="mobius_post_subtitle_field">
            </p>

            <p>
                <label for="mobius_post_layout_field"><?php echo esc_html('Layout'); ?></label>
                <br />
                <select class="widefat" name="mobius_post_layout_field" id="mobius_post_layout_field">
                    <option <?php selected($layout, 'full') ?> value="full"><?php echo esc_html('Full Width'); ?></option>
                    <option <?php selected($layout, 'sidebar') ?> value="sidebar"><?php echo esc_html('Sidebar'); ?></option>
                </select>
            </p>
        <?php
    }

    function mobius_save_post_meta_box($post_id, $post) {

        $edit_cap = get_post_type_object($post->post_type)->cap->edit_post;
        if( !current_user_can( $edit_cap, $post_id ) ) {
            return;
        }

        if( !isset($_POST['themename_update_post_nonce']) || !wp_verify_nonce( $_POST['themename_update_post_nonce'], 'mobius_update_post_metabox' ) ) {
            return;
        }

        if( array_key_exists('mobius_post_subtitle_field', $_POST) ) {
            update_post_meta( 
                $post_id,
                '__mobius_post_subtitle',
                sanitize_text_field($_POST['mobius_post_subtitle_field'])
            );
        };

        if( array_key_exists('mobius_post_layout_field', $_POST) ) {
            update_post_meta( 
                $post_id,
                '__mobius_post_layout',
                sanitize_text_field($_POST['mobius_post_layout_field'])
            );
        };
        
    }
    add_action('save_post', 'mobius_save_post_meta_box', 10, 2);